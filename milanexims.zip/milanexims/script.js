document.querySelector(".hero-content").animate(
  [
    { opacity: 0, transform: "translateY(30px)" },
    { opacity: 1, transform: "translateY(0)" }
  ],
  {
    duration: 1200,
    easing: "ease-out",
    fill: "forwards"
  }
);





